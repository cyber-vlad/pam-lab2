import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:course_app_lab2/models/category.dart';
import 'package:course_app_lab2/models/lite_course.dart';
import 'package:course_app_lab2/models/course_details.dart';
class CoursesRepository {

  Future<CoursesPayload> load() async {
    // se incarc datele din json (async)
    final raw = await rootBundle.loadString('assets/data/courses.json'); 

    // textul json se transorma intro structura de date Map (cheie-valoare)
    final Map<String, dynamic> data = jsonDecode(raw);

    final categories = Category.listFromJson(
      (data['categories'] as List?) ?? const [],
    );

final suggestions =
        LiteCourse.listFromJson((data['suggestions'] as List?) ?? const []);
    final topCourses =
        LiteCourse.listFromJson((data['topCourses'] as List?) ?? const []);
    final continueWatchingRaw = (data['continueWatching'] as List?) ?? const [];
final continueWatching = continueWatchingRaw
    .map((e) => ContinueWatchingItem.fromJson(e as Map<String, dynamic>))
    .toList();

    return CoursesPayload(
      categories: categories,
      suggestions: suggestions,
      topCourses: topCourses,
      continueWatching: continueWatching,
    );
  }

   Future<CourseDetails> loadDetailsById(String courseId) async {
    // convenție de nume: assets/data/details/<id>.json
    final path = 'assets/data/$courseId.json';
    final raw = await rootBundle.loadString(path);
    final Map<String, dynamic> json = jsonDecode(raw);
    return CourseDetails.fromJson(json);
  }
}

class ContinueWatchingItem {
  final String id;
  final String title;
  final String institute;
  /// 0.0 .. 1.0  (transformăm din procente)
  final double progress;
  final double rating;
  final String imageUrl;

  ContinueWatchingItem({
    required this.id,
    required this.title,
    required this.institute,
    required this.progress,
    required this.rating,
    required this.imageUrl,
  });

  
  factory ContinueWatchingItem.fromJson(Map<String, dynamic> json) =>
      ContinueWatchingItem(
        id: json['id'] ?? '',
        title: json['title'] ?? '',
        institute: json['institute'] ?? '',
        // JSON are progress în procente (ex: 79) -> UI vrea 0..1
        progress: ((json['progress'] as num?)?.toDouble() ?? 0.0) / 100.0,
        rating: (json['rating'] as num?)?.toDouble() ?? 0.0,
        // câmpul nou e "image"; dar acceptăm și "imageUrl" ca fallback
        imageUrl: (json['image'] ?? json['imageUrl'] ?? '') as String,
      );
}

class CoursesPayload {
  final List<Category> categories;
  final List<LiteCourse> suggestions;
  final List<LiteCourse> topCourses;
  final List<ContinueWatchingItem> continueWatching;

  CoursesPayload({
    required this.categories,
    required this.suggestions,
    required this.topCourses,
    required this.continueWatching,
  });
}
